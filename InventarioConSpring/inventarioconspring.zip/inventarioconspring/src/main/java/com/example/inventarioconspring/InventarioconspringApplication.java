package com.example.inventarioconspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InventarioconspringApplication {

	public static void main(String[] args) {
		SpringApplication.run(InventarioconspringApplication.class, args);
	}

}
