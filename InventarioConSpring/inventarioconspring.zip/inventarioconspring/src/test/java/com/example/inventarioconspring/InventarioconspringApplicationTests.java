package com.example.inventarioconspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InventarioconspringApplicationTests {

	@Test
	void contextLoads() {
	}

}
