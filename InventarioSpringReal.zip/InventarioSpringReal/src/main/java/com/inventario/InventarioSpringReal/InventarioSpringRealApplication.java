package com.inventario.InventarioSpringReal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InventarioSpringRealApplication {

	public static void main(String[] args) {
		SpringApplication.run(InventarioSpringRealApplication.class, args);
	}

}
