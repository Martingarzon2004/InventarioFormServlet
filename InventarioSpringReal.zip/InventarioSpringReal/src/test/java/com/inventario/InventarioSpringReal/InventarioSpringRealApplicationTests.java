package com.inventario.InventarioSpringReal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InventarioSpringRealApplicationTests {

	@Test
	void contextLoads() {
	}

}
